///////INTRODUCTION//////
First, this is not my mod, but PeteTimesSix's one.
As I understood, I have the permissions to distribute this mod as long as I put the licence.txt, which I did.

The links to download the mod recently brokes, so I download the source code and barely make it work.

//////INSTALLATION//////
To have the mod working, you first need ModuleManager and Toolbar OR/AND RasterPropMonitor
Then directly place the VesselView folder into your KSP's GameData folder
That's all, it SHOULD work.

//////INFORMATIONS//////
I have installed on my v1.0.5 Kerbal Space Program : ModuleManager, RasterPropMonitor, TAC life support, and a lots of other mods
It work normally
	
I know nothing about coding, but if you have a problem, something not working, a crash or anything else : Contact me.

Have fun !